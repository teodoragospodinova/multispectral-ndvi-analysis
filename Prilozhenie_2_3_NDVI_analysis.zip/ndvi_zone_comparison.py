
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("sample_pixel_data.csv")
zone_a = data[data["zone"] == "a"]["ndvi"]
zone_b = data[data["zone"] == "b"]["ndvi"]

plt.hist(zone_a, bins=20, alpha=0.6, label="Зона А")
plt.hist(zone_b, bins=20, alpha=0.6, label="Зона Б")
plt.xlabel("NDVI стойности")
plt.ylabel("Брой пиксели")
plt.legend()
plt.title("Сравнение на NDVI по зони")
plt.savefig("ndvi_hist_compare.png")
